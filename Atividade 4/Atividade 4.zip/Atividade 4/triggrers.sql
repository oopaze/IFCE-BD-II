-- 4. Crie um Trigger para atualizar a View
--    sempre que uma venda for realizada até que o 
--    estoque fique igual ou abaixo do mínimo




-- 5. Crie um Trigger para disparar quando uma
--    venda for inserida. Ela deve checar se a 
--    quantidade vendida está disponível no estoque. 
--    Caso esteja, a venda se concretiza, caso contrário, 
--    a venda deverá ser cancelada e uma mensagem de erro 
--    deverá ser enviada

